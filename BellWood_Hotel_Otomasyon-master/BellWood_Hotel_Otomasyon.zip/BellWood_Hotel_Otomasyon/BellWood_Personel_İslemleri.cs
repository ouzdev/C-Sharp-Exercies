﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BellWood_Hotel_Otomasyon
{
    public partial class BellWood_Personel_İslemleri : Form
    {
        public BellWood_Personel_İslemleri()
        {
            InitializeComponent();
        }
    }
}
