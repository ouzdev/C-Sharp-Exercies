﻿namespace BellWood_Hotel_Otomasyon
{
    partial class MusteriEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnOda3008 = new System.Windows.Forms.Button();
            this.btnOda3007 = new System.Windows.Forms.Button();
            this.btnOda3006 = new System.Windows.Forms.Button();
            this.btnOda3005 = new System.Windows.Forms.Button();
            this.btnOda3004 = new System.Windows.Forms.Button();
            this.btnOda3002 = new System.Windows.Forms.Button();
            this.btnOda3003 = new System.Windows.Forms.Button();
            this.btnOda3001 = new System.Windows.Forms.Button();
            this.btnOda2007 = new System.Windows.Forms.Button();
            this.btnOda2008 = new System.Windows.Forms.Button();
            this.btnOda2005 = new System.Windows.Forms.Button();
            this.btnOda2004 = new System.Windows.Forms.Button();
            this.btnOda2006 = new System.Windows.Forms.Button();
            this.btnOda2003 = new System.Windows.Forms.Button();
            this.btnOda2002 = new System.Windows.Forms.Button();
            this.btnOda1008 = new System.Windows.Forms.Button();
            this.btnOda1007 = new System.Windows.Forms.Button();
            this.btnOda2001 = new System.Windows.Forms.Button();
            this.btnOda1006 = new System.Windows.Forms.Button();
            this.btnOda1005 = new System.Windows.Forms.Button();
            this.btnOda1004 = new System.Windows.Forms.Button();
            this.btnOda1003 = new System.Windows.Forms.Button();
            this.btnOda1002 = new System.Windows.Forms.Button();
            this.btnOda1001 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_toplam_gün = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmb_cinsiyet = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_Fiyat = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_musteri_kaydet = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_oda_no = new System.Windows.Forms.TextBox();
            this.msk_tel_no = new System.Windows.Forms.MaskedTextBox();
            this.msk_tc_no = new System.Windows.Forms.MaskedTextBox();
            this.txt_musteri_soyadi = new System.Windows.Forms.TextBox();
            this.txt_musteri_adi = new System.Windows.Forms.TextBox();
            this.dtp_cikis_tarihi = new System.Windows.Forms.DateTimePicker();
            this.dtp_giris_tarihi = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnOda3008);
            this.groupBox2.Controls.Add(this.btnOda3007);
            this.groupBox2.Controls.Add(this.btnOda3006);
            this.groupBox2.Controls.Add(this.btnOda3005);
            this.groupBox2.Controls.Add(this.btnOda3004);
            this.groupBox2.Controls.Add(this.btnOda3002);
            this.groupBox2.Controls.Add(this.btnOda3003);
            this.groupBox2.Controls.Add(this.btnOda3001);
            this.groupBox2.Controls.Add(this.btnOda2007);
            this.groupBox2.Controls.Add(this.btnOda2008);
            this.groupBox2.Controls.Add(this.btnOda2005);
            this.groupBox2.Controls.Add(this.btnOda2004);
            this.groupBox2.Controls.Add(this.btnOda2006);
            this.groupBox2.Controls.Add(this.btnOda2003);
            this.groupBox2.Controls.Add(this.btnOda2002);
            this.groupBox2.Controls.Add(this.btnOda1008);
            this.groupBox2.Controls.Add(this.btnOda1007);
            this.groupBox2.Controls.Add(this.btnOda2001);
            this.groupBox2.Controls.Add(this.btnOda1006);
            this.groupBox2.Controls.Add(this.btnOda1005);
            this.groupBox2.Controls.Add(this.btnOda1004);
            this.groupBox2.Controls.Add(this.btnOda1003);
            this.groupBox2.Controls.Add(this.btnOda1002);
            this.groupBox2.Controls.Add(this.btnOda1001);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(12, 301);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1114, 359);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Odalar";
            // 
            // btnOda3008
            // 
            this.btnOda3008.BackColor = System.Drawing.Color.Lime;
            this.btnOda3008.Location = new System.Drawing.Point(958, 250);
            this.btnOda3008.Name = "btnOda3008";
            this.btnOda3008.Size = new System.Drawing.Size(101, 76);
            this.btnOda3008.TabIndex = 19;
            this.btnOda3008.Text = "3008";
            this.btnOda3008.UseVisualStyleBackColor = false;
            // 
            // btnOda3007
            // 
            this.btnOda3007.BackColor = System.Drawing.Color.Lime;
            this.btnOda3007.Location = new System.Drawing.Point(833, 250);
            this.btnOda3007.Name = "btnOda3007";
            this.btnOda3007.Size = new System.Drawing.Size(101, 76);
            this.btnOda3007.TabIndex = 18;
            this.btnOda3007.Text = "3007";
            this.btnOda3007.UseVisualStyleBackColor = false;
            // 
            // btnOda3006
            // 
            this.btnOda3006.BackColor = System.Drawing.Color.Lime;
            this.btnOda3006.Location = new System.Drawing.Point(708, 250);
            this.btnOda3006.Name = "btnOda3006";
            this.btnOda3006.Size = new System.Drawing.Size(101, 76);
            this.btnOda3006.TabIndex = 17;
            this.btnOda3006.Text = "3006";
            this.btnOda3006.UseVisualStyleBackColor = false;
            // 
            // btnOda3005
            // 
            this.btnOda3005.BackColor = System.Drawing.Color.Lime;
            this.btnOda3005.Location = new System.Drawing.Point(584, 250);
            this.btnOda3005.Name = "btnOda3005";
            this.btnOda3005.Size = new System.Drawing.Size(101, 76);
            this.btnOda3005.TabIndex = 16;
            this.btnOda3005.Text = "3005";
            this.btnOda3005.UseVisualStyleBackColor = false;
            this.btnOda3005.Click += new System.EventHandler(this.btnOda3005_Click);
            // 
            // btnOda3004
            // 
            this.btnOda3004.BackColor = System.Drawing.Color.Lime;
            this.btnOda3004.Location = new System.Drawing.Point(456, 250);
            this.btnOda3004.Name = "btnOda3004";
            this.btnOda3004.Size = new System.Drawing.Size(101, 76);
            this.btnOda3004.TabIndex = 15;
            this.btnOda3004.Text = "3004";
            this.btnOda3004.UseVisualStyleBackColor = false;
            this.btnOda3004.Click += new System.EventHandler(this.btnOda3004_Click);
            // 
            // btnOda3002
            // 
            this.btnOda3002.BackColor = System.Drawing.Color.Lime;
            this.btnOda3002.Location = new System.Drawing.Point(204, 250);
            this.btnOda3002.Name = "btnOda3002";
            this.btnOda3002.Size = new System.Drawing.Size(101, 76);
            this.btnOda3002.TabIndex = 14;
            this.btnOda3002.Text = "3002";
            this.btnOda3002.UseVisualStyleBackColor = false;
            this.btnOda3002.Click += new System.EventHandler(this.btnOda3002_Click);
            // 
            // btnOda3003
            // 
            this.btnOda3003.BackColor = System.Drawing.Color.Lime;
            this.btnOda3003.Location = new System.Drawing.Point(333, 250);
            this.btnOda3003.Name = "btnOda3003";
            this.btnOda3003.Size = new System.Drawing.Size(101, 76);
            this.btnOda3003.TabIndex = 14;
            this.btnOda3003.Text = "3003";
            this.btnOda3003.UseVisualStyleBackColor = false;
            this.btnOda3003.Click += new System.EventHandler(this.btnOda3003_Click);
            // 
            // btnOda3001
            // 
            this.btnOda3001.BackColor = System.Drawing.Color.Lime;
            this.btnOda3001.Location = new System.Drawing.Point(73, 250);
            this.btnOda3001.Name = "btnOda3001";
            this.btnOda3001.Size = new System.Drawing.Size(101, 76);
            this.btnOda3001.TabIndex = 13;
            this.btnOda3001.Text = "3001";
            this.btnOda3001.UseVisualStyleBackColor = false;
            this.btnOda3001.Click += new System.EventHandler(this.btnOda3001_Click);
            // 
            // btnOda2007
            // 
            this.btnOda2007.BackColor = System.Drawing.Color.Lime;
            this.btnOda2007.Location = new System.Drawing.Point(833, 148);
            this.btnOda2007.Name = "btnOda2007";
            this.btnOda2007.Size = new System.Drawing.Size(101, 76);
            this.btnOda2007.TabIndex = 12;
            this.btnOda2007.Text = "2007";
            this.btnOda2007.UseVisualStyleBackColor = false;
            this.btnOda2007.Click += new System.EventHandler(this.btnOda2007_Click);
            // 
            // btnOda2008
            // 
            this.btnOda2008.BackColor = System.Drawing.Color.Lime;
            this.btnOda2008.Location = new System.Drawing.Point(958, 148);
            this.btnOda2008.Name = "btnOda2008";
            this.btnOda2008.Size = new System.Drawing.Size(101, 76);
            this.btnOda2008.TabIndex = 12;
            this.btnOda2008.Text = "2008";
            this.btnOda2008.UseVisualStyleBackColor = false;
            this.btnOda2008.Click += new System.EventHandler(this.btnOda2008_Click);
            // 
            // btnOda2005
            // 
            this.btnOda2005.BackColor = System.Drawing.Color.Lime;
            this.btnOda2005.Location = new System.Drawing.Point(584, 148);
            this.btnOda2005.Name = "btnOda2005";
            this.btnOda2005.Size = new System.Drawing.Size(101, 76);
            this.btnOda2005.TabIndex = 11;
            this.btnOda2005.Text = "2005";
            this.btnOda2005.UseVisualStyleBackColor = false;
            this.btnOda2005.Click += new System.EventHandler(this.btnOda2005_Click);
            // 
            // btnOda2004
            // 
            this.btnOda2004.BackColor = System.Drawing.Color.Lime;
            this.btnOda2004.Location = new System.Drawing.Point(456, 148);
            this.btnOda2004.Name = "btnOda2004";
            this.btnOda2004.Size = new System.Drawing.Size(101, 76);
            this.btnOda2004.TabIndex = 10;
            this.btnOda2004.Text = "2004";
            this.btnOda2004.UseVisualStyleBackColor = false;
            this.btnOda2004.Click += new System.EventHandler(this.btnOda2004_Click);
            // 
            // btnOda2006
            // 
            this.btnOda2006.BackColor = System.Drawing.Color.Lime;
            this.btnOda2006.Location = new System.Drawing.Point(708, 148);
            this.btnOda2006.Name = "btnOda2006";
            this.btnOda2006.Size = new System.Drawing.Size(101, 76);
            this.btnOda2006.TabIndex = 10;
            this.btnOda2006.Text = "2006";
            this.btnOda2006.UseVisualStyleBackColor = false;
            this.btnOda2006.Click += new System.EventHandler(this.btnOda2006_Click);
            // 
            // btnOda2003
            // 
            this.btnOda2003.BackColor = System.Drawing.Color.Lime;
            this.btnOda2003.Location = new System.Drawing.Point(333, 148);
            this.btnOda2003.Name = "btnOda2003";
            this.btnOda2003.Size = new System.Drawing.Size(101, 76);
            this.btnOda2003.TabIndex = 9;
            this.btnOda2003.Text = "2003";
            this.btnOda2003.UseVisualStyleBackColor = false;
            this.btnOda2003.Click += new System.EventHandler(this.btnOda2003_Click);
            // 
            // btnOda2002
            // 
            this.btnOda2002.BackColor = System.Drawing.Color.Lime;
            this.btnOda2002.Location = new System.Drawing.Point(204, 148);
            this.btnOda2002.Name = "btnOda2002";
            this.btnOda2002.Size = new System.Drawing.Size(101, 76);
            this.btnOda2002.TabIndex = 8;
            this.btnOda2002.Text = "2002";
            this.btnOda2002.UseVisualStyleBackColor = false;
            this.btnOda2002.Click += new System.EventHandler(this.btnOda2002_Click);
            // 
            // btnOda1008
            // 
            this.btnOda1008.BackColor = System.Drawing.Color.Lime;
            this.btnOda1008.Location = new System.Drawing.Point(958, 34);
            this.btnOda1008.Name = "btnOda1008";
            this.btnOda1008.Size = new System.Drawing.Size(101, 76);
            this.btnOda1008.TabIndex = 7;
            this.btnOda1008.Text = "1008";
            this.btnOda1008.UseVisualStyleBackColor = false;
            this.btnOda1008.Click += new System.EventHandler(this.btnOda1008_Click);
            // 
            // btnOda1007
            // 
            this.btnOda1007.BackColor = System.Drawing.Color.Lime;
            this.btnOda1007.Location = new System.Drawing.Point(833, 34);
            this.btnOda1007.Name = "btnOda1007";
            this.btnOda1007.Size = new System.Drawing.Size(101, 76);
            this.btnOda1007.TabIndex = 6;
            this.btnOda1007.Text = "1007";
            this.btnOda1007.UseVisualStyleBackColor = false;
            this.btnOda1007.Click += new System.EventHandler(this.btnOda1007_Click);
            // 
            // btnOda2001
            // 
            this.btnOda2001.BackColor = System.Drawing.Color.Lime;
            this.btnOda2001.Location = new System.Drawing.Point(74, 148);
            this.btnOda2001.Name = "btnOda2001";
            this.btnOda2001.Size = new System.Drawing.Size(101, 76);
            this.btnOda2001.TabIndex = 6;
            this.btnOda2001.Text = "2001";
            this.btnOda2001.UseVisualStyleBackColor = false;
            this.btnOda2001.Click += new System.EventHandler(this.btnOda2001_Click);
            // 
            // btnOda1006
            // 
            this.btnOda1006.BackColor = System.Drawing.Color.Lime;
            this.btnOda1006.Location = new System.Drawing.Point(708, 34);
            this.btnOda1006.Name = "btnOda1006";
            this.btnOda1006.Size = new System.Drawing.Size(101, 76);
            this.btnOda1006.TabIndex = 5;
            this.btnOda1006.Text = "1006";
            this.btnOda1006.UseVisualStyleBackColor = false;
            this.btnOda1006.Click += new System.EventHandler(this.btnOda1006_Click);
            // 
            // btnOda1005
            // 
            this.btnOda1005.BackColor = System.Drawing.Color.Lime;
            this.btnOda1005.Location = new System.Drawing.Point(584, 34);
            this.btnOda1005.Name = "btnOda1005";
            this.btnOda1005.Size = new System.Drawing.Size(101, 76);
            this.btnOda1005.TabIndex = 4;
            this.btnOda1005.Text = "1005";
            this.btnOda1005.UseVisualStyleBackColor = false;
            this.btnOda1005.Click += new System.EventHandler(this.btnOda1005_Click);
            // 
            // btnOda1004
            // 
            this.btnOda1004.BackColor = System.Drawing.Color.Lime;
            this.btnOda1004.Location = new System.Drawing.Point(456, 34);
            this.btnOda1004.Name = "btnOda1004";
            this.btnOda1004.Size = new System.Drawing.Size(101, 76);
            this.btnOda1004.TabIndex = 3;
            this.btnOda1004.Text = "1004";
            this.btnOda1004.UseVisualStyleBackColor = false;
            this.btnOda1004.Click += new System.EventHandler(this.btnOda1004_Click);
            // 
            // btnOda1003
            // 
            this.btnOda1003.BackColor = System.Drawing.Color.Lime;
            this.btnOda1003.Location = new System.Drawing.Point(333, 34);
            this.btnOda1003.Name = "btnOda1003";
            this.btnOda1003.Size = new System.Drawing.Size(101, 76);
            this.btnOda1003.TabIndex = 2;
            this.btnOda1003.Text = "1003";
            this.btnOda1003.UseVisualStyleBackColor = false;
            this.btnOda1003.Click += new System.EventHandler(this.btnOda1003_Click);
            // 
            // btnOda1002
            // 
            this.btnOda1002.BackColor = System.Drawing.Color.Lime;
            this.btnOda1002.Location = new System.Drawing.Point(204, 34);
            this.btnOda1002.Name = "btnOda1002";
            this.btnOda1002.Size = new System.Drawing.Size(101, 76);
            this.btnOda1002.TabIndex = 1;
            this.btnOda1002.Text = "1002";
            this.btnOda1002.UseVisualStyleBackColor = false;
            this.btnOda1002.Click += new System.EventHandler(this.btnOda1002_Click);
            // 
            // btnOda1001
            // 
            this.btnOda1001.BackColor = System.Drawing.Color.Lime;
            this.btnOda1001.Location = new System.Drawing.Point(73, 34);
            this.btnOda1001.Name = "btnOda1001";
            this.btnOda1001.Size = new System.Drawing.Size(101, 76);
            this.btnOda1001.TabIndex = 0;
            this.btnOda1001.Text = "1001";
            this.btnOda1001.UseVisualStyleBackColor = false;
            this.btnOda1001.Click += new System.EventHandler(this.btnOda1001_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_toplam_gün);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cmb_cinsiyet);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_Fiyat);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btn_musteri_kaydet);
            this.groupBox1.Controls.Add(this.button27);
            this.groupBox1.Controls.Add(this.button26);
            this.groupBox1.Controls.Add(this.txt_email);
            this.groupBox1.Controls.Add(this.txt_oda_no);
            this.groupBox1.Controls.Add(this.msk_tel_no);
            this.groupBox1.Controls.Add(this.msk_tc_no);
            this.groupBox1.Controls.Add(this.txt_musteri_soyadi);
            this.groupBox1.Controls.Add(this.txt_musteri_adi);
            this.groupBox1.Controls.Add(this.dtp_cikis_tarihi);
            this.groupBox1.Controls.Add(this.dtp_giris_tarihi);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1114, 266);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Müşteri Bilgileri";
            // 
            // lbl_toplam_gün
            // 
            this.lbl_toplam_gün.AutoSize = true;
            this.lbl_toplam_gün.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_toplam_gün.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_toplam_gün.Location = new System.Drawing.Point(888, 33);
            this.lbl_toplam_gün.Name = "lbl_toplam_gün";
            this.lbl_toplam_gün.Size = new System.Drawing.Size(19, 22);
            this.lbl_toplam_gün.TabIndex = 28;
            this.lbl_toplam_gün.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(777, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 22);
            this.label11.TabIndex = 27;
            this.label11.Text = "Toplam Gün : ";
            // 
            // cmb_cinsiyet
            // 
            this.cmb_cinsiyet.FormattingEnabled = true;
            this.cmb_cinsiyet.Items.AddRange(new object[] {
            "Bay",
            "Bayan"});
            this.cmb_cinsiyet.Location = new System.Drawing.Point(186, 97);
            this.cmb_cinsiyet.Name = "cmb_cinsiyet";
            this.cmb_cinsiyet.Size = new System.Drawing.Size(179, 28);
            this.cmb_cinsiyet.TabIndex = 26;
            this.cmb_cinsiyet.Text = "Bay";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(108, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 22);
            this.label10.TabIndex = 25;
            this.label10.Text = "Cinsiyet :";
            // 
            // txt_Fiyat
            // 
            this.txt_Fiyat.Location = new System.Drawing.Point(516, 71);
            this.txt_Fiyat.Name = "txt_Fiyat";
            this.txt_Fiyat.Size = new System.Drawing.Size(200, 27);
            this.txt_Fiyat.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(458, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 22);
            this.label9.TabIndex = 23;
            this.label9.Text = "Fiyat :";
            // 
            // btn_musteri_kaydet
            // 
            this.btn_musteri_kaydet.BackColor = System.Drawing.Color.Gold;
            this.btn_musteri_kaydet.Location = new System.Drawing.Point(431, 215);
            this.btn_musteri_kaydet.Name = "btn_musteri_kaydet";
            this.btn_musteri_kaydet.Size = new System.Drawing.Size(289, 45);
            this.btn_musteri_kaydet.TabIndex = 22;
            this.btn_musteri_kaydet.Text = "Müşteriyi Kaydet";
            this.btn_musteri_kaydet.UseVisualStyleBackColor = false;
            this.btn_musteri_kaydet.Click += new System.EventHandler(this.btn_musteri_kaydet_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Red;
            this.button27.Location = new System.Drawing.Point(945, 84);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(157, 116);
            this.button27.TabIndex = 21;
            this.button27.Text = "DOLU";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Lime;
            this.button26.Location = new System.Drawing.Point(777, 84);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(157, 114);
            this.button26.TabIndex = 20;
            this.button26.Text = "BOŞ";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(186, 194);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(179, 27);
            this.txt_email.TabIndex = 14;
            // 
            // txt_oda_no
            // 
            this.txt_oda_no.Enabled = false;
            this.txt_oda_no.Location = new System.Drawing.Point(512, 30);
            this.txt_oda_no.Name = "txt_oda_no";
            this.txt_oda_no.Size = new System.Drawing.Size(204, 27);
            this.txt_oda_no.TabIndex = 13;
            // 
            // msk_tel_no
            // 
            this.msk_tel_no.Location = new System.Drawing.Point(186, 162);
            this.msk_tel_no.Mask = "(999) 000-0000";
            this.msk_tel_no.Name = "msk_tel_no";
            this.msk_tel_no.Size = new System.Drawing.Size(179, 27);
            this.msk_tel_no.TabIndex = 12;
            // 
            // msk_tc_no
            // 
            this.msk_tc_no.Location = new System.Drawing.Point(186, 130);
            this.msk_tc_no.Mask = "00000000000";
            this.msk_tc_no.Name = "msk_tc_no";
            this.msk_tc_no.Size = new System.Drawing.Size(179, 27);
            this.msk_tc_no.TabIndex = 11;
            this.msk_tc_no.ValidatingType = typeof(int);
            // 
            // txt_musteri_soyadi
            // 
            this.txt_musteri_soyadi.Location = new System.Drawing.Point(186, 65);
            this.txt_musteri_soyadi.Name = "txt_musteri_soyadi";
            this.txt_musteri_soyadi.Size = new System.Drawing.Size(179, 27);
            this.txt_musteri_soyadi.TabIndex = 10;
            // 
            // txt_musteri_adi
            // 
            this.txt_musteri_adi.Location = new System.Drawing.Point(186, 33);
            this.txt_musteri_adi.Name = "txt_musteri_adi";
            this.txt_musteri_adi.Size = new System.Drawing.Size(179, 27);
            this.txt_musteri_adi.TabIndex = 9;
            // 
            // dtp_cikis_tarihi
            // 
            this.dtp_cikis_tarihi.Location = new System.Drawing.Point(516, 173);
            this.dtp_cikis_tarihi.Name = "dtp_cikis_tarihi";
            this.dtp_cikis_tarihi.Size = new System.Drawing.Size(200, 27);
            this.dtp_cikis_tarihi.TabIndex = 8;
            this.dtp_cikis_tarihi.ValueChanged += new System.EventHandler(this.dtp_cikis_tarihi_ValueChanged);
            // 
            // dtp_giris_tarihi
            // 
            this.dtp_giris_tarihi.Location = new System.Drawing.Point(520, 126);
            this.dtp_giris_tarihi.Name = "dtp_giris_tarihi";
            this.dtp_giris_tarihi.Size = new System.Drawing.Size(196, 27);
            this.dtp_giris_tarihi.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(419, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "Giriş Tarihi :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(388, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 22);
            this.label7.TabIndex = 5;
            this.label7.Text = "Oda Numarası :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(415, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Çıkış Tarihi :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(64, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "E-Posta Adresi :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(67, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "T.C. Numarası :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(102, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Telefonu :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Müşteri Soyadı :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Müşteri Adı :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1138, 672);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(958, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 76);
            this.button1.TabIndex = 19;
            this.button1.Text = "3008";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Location = new System.Drawing.Point(833, 250);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 76);
            this.button2.TabIndex = 18;
            this.button2.Text = "3007";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(708, 250);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 76);
            this.button3.TabIndex = 17;
            this.button3.Text = "3006";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Lime;
            this.button4.Location = new System.Drawing.Point(584, 250);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 76);
            this.button4.TabIndex = 16;
            this.button4.Text = "3005";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Lime;
            this.button5.Location = new System.Drawing.Point(456, 250);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(101, 76);
            this.button5.TabIndex = 15;
            this.button5.Text = "3004";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Lime;
            this.button6.Location = new System.Drawing.Point(204, 250);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(101, 76);
            this.button6.TabIndex = 14;
            this.button6.Text = "3002";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Lime;
            this.button7.Location = new System.Drawing.Point(333, 250);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(101, 76);
            this.button7.TabIndex = 14;
            this.button7.Text = "3003";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Lime;
            this.button8.Location = new System.Drawing.Point(73, 250);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(101, 76);
            this.button8.TabIndex = 13;
            this.button8.Text = "3001";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Lime;
            this.button9.Location = new System.Drawing.Point(833, 148);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 76);
            this.button9.TabIndex = 12;
            this.button9.Text = "2007";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Lime;
            this.button10.Location = new System.Drawing.Point(958, 148);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(101, 76);
            this.button10.TabIndex = 12;
            this.button10.Text = "2008";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Lime;
            this.button11.Location = new System.Drawing.Point(584, 148);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 76);
            this.button11.TabIndex = 11;
            this.button11.Text = "2005";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Lime;
            this.button12.Location = new System.Drawing.Point(456, 148);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(101, 76);
            this.button12.TabIndex = 10;
            this.button12.Text = "2004";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Lime;
            this.button13.Location = new System.Drawing.Point(708, 148);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(101, 76);
            this.button13.TabIndex = 10;
            this.button13.Text = "2006";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Lime;
            this.button14.Location = new System.Drawing.Point(333, 148);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(101, 76);
            this.button14.TabIndex = 9;
            this.button14.Text = "2003";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Lime;
            this.button15.Location = new System.Drawing.Point(204, 148);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(101, 76);
            this.button15.TabIndex = 8;
            this.button15.Text = "2002";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Lime;
            this.button16.Location = new System.Drawing.Point(958, 34);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(101, 76);
            this.button16.TabIndex = 7;
            this.button16.Text = "1008";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Lime;
            this.button17.Location = new System.Drawing.Point(833, 34);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(101, 76);
            this.button17.TabIndex = 6;
            this.button17.Text = "1007";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Lime;
            this.button18.Location = new System.Drawing.Point(74, 148);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(101, 76);
            this.button18.TabIndex = 6;
            this.button18.Text = "2001";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Lime;
            this.button19.Location = new System.Drawing.Point(708, 34);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(101, 76);
            this.button19.TabIndex = 5;
            this.button19.Text = "1006";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Lime;
            this.button20.Location = new System.Drawing.Point(584, 34);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(101, 76);
            this.button20.TabIndex = 4;
            this.button20.Text = "1005";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Lime;
            this.button21.Location = new System.Drawing.Point(456, 34);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(101, 76);
            this.button21.TabIndex = 3;
            this.button21.Text = "1004";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Lime;
            this.button22.Location = new System.Drawing.Point(333, 34);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(101, 76);
            this.button22.TabIndex = 2;
            this.button22.Text = "1003";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Lime;
            this.button23.Location = new System.Drawing.Point(204, 34);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(101, 76);
            this.button23.TabIndex = 1;
            this.button23.Text = "1002";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Lime;
            this.button24.Location = new System.Drawing.Point(73, 34);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(101, 76);
            this.button24.TabIndex = 0;
            this.button24.Text = "1001";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = global::BellWood_Hotel_Otomasyon.Properties.Resources.simple_blue_background_abstract_photo_blue_background;
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.button10);
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.button13);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.button15);
            this.groupBox3.Controls.Add(this.button16);
            this.groupBox3.Controls.Add(this.button17);
            this.groupBox3.Controls.Add(this.button18);
            this.groupBox3.Controls.Add(this.button19);
            this.groupBox3.Controls.Add(this.button20);
            this.groupBox3.Controls.Add(this.button21);
            this.groupBox3.Controls.Add(this.button22);
            this.groupBox3.Controls.Add(this.button23);
            this.groupBox3.Controls.Add(this.button24);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.Location = new System.Drawing.Point(63, 132);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1114, 359);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Odalar";
            // 
            // MusteriEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1138, 672);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MusteriEkrani";
            this.Text = "Yeni Müşteri Ekleme Ekranı";
            this.Load += new System.EventHandler(this.MusteriEkrani_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtp_cikis_tarihi;
        private System.Windows.Forms.DateTimePicker dtp_giris_tarihi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_oda_no;
        private System.Windows.Forms.MaskedTextBox msk_tel_no;
        private System.Windows.Forms.MaskedTextBox msk_tc_no;
        private System.Windows.Forms.TextBox txt_musteri_soyadi;
        private System.Windows.Forms.TextBox txt_musteri_adi;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnOda3002;
        private System.Windows.Forms.Button btnOda3003;
        private System.Windows.Forms.Button btnOda3001;
        private System.Windows.Forms.Button btnOda2007;
        private System.Windows.Forms.Button btnOda2008;
        private System.Windows.Forms.Button btnOda2005;
        private System.Windows.Forms.Button btnOda2004;
        private System.Windows.Forms.Button btnOda2006;
        private System.Windows.Forms.Button btnOda2003;
        private System.Windows.Forms.Button btnOda2002;
        private System.Windows.Forms.Button btnOda1008;
        private System.Windows.Forms.Button btnOda1007;
        private System.Windows.Forms.Button btnOda2001;
        private System.Windows.Forms.Button btnOda1006;
        private System.Windows.Forms.Button btnOda1005;
        private System.Windows.Forms.Button btnOda1004;
        private System.Windows.Forms.Button btnOda1003;
        private System.Windows.Forms.Button btnOda1002;
        private System.Windows.Forms.Button btnOda1001;
        private System.Windows.Forms.Button btnOda3008;
        private System.Windows.Forms.Button btnOda3007;
        private System.Windows.Forms.Button btnOda3006;
        private System.Windows.Forms.Button btnOda3005;
        private System.Windows.Forms.Button btnOda3004;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button btn_musteri_kaydet;
        private System.Windows.Forms.TextBox txt_Fiyat;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmb_cinsiyet;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_toplam_gün;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}