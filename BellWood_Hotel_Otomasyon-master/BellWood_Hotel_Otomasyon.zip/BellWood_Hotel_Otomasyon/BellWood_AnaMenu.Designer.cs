﻿namespace BellWood_Hotel_Otomasyon
{
    partial class BellWood_AnaMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_admin_giris = new System.Windows.Forms.Button();
            this.btn_yeni_musteri_ekle = new System.Windows.Forms.Button();
            this.btn_odalar = new System.Windows.Forms.Button();
            this.btn_musteri_liste = new System.Windows.Forms.Button();
            this.btn_personel = new System.Windows.Forms.Button();
            this.btn_stok = new System.Windows.Forms.Button();
            this.btn_feedback = new System.Windows.Forms.Button();
            this.btn_info = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::BellWood_Hotel_Otomasyon.Properties.Resources._275b70ad236e6cf238b3165b61413dd2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1175, 759);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btn_admin_giris
            // 
            this.btn_admin_giris.BackColor = System.Drawing.Color.White;
            this.btn_admin_giris.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_giris.Location = new System.Drawing.Point(681, 530);
            this.btn_admin_giris.Name = "btn_admin_giris";
            this.btn_admin_giris.Size = new System.Drawing.Size(116, 104);
            this.btn_admin_giris.TabIndex = 1;
            this.btn_admin_giris.Text = "Super User";
            this.btn_admin_giris.UseVisualStyleBackColor = false;
            this.btn_admin_giris.Click += new System.EventHandler(this.btn_admin_giris_Click);
            // 
            // btn_yeni_musteri_ekle
            // 
            this.btn_yeni_musteri_ekle.BackColor = System.Drawing.Color.White;
            this.btn_yeni_musteri_ekle.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_yeni_musteri_ekle.Location = new System.Drawing.Point(925, 530);
            this.btn_yeni_musteri_ekle.Name = "btn_yeni_musteri_ekle";
            this.btn_yeni_musteri_ekle.Size = new System.Drawing.Size(116, 104);
            this.btn_yeni_musteri_ekle.TabIndex = 2;
            this.btn_yeni_musteri_ekle.Text = "Check-In";
            this.btn_yeni_musteri_ekle.UseVisualStyleBackColor = false;
            this.btn_yeni_musteri_ekle.Click += new System.EventHandler(this.btn_yeni_musteri_ekle_Click);
            // 
            // btn_odalar
            // 
            this.btn_odalar.BackColor = System.Drawing.Color.White;
            this.btn_odalar.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_odalar.Location = new System.Drawing.Point(1047, 530);
            this.btn_odalar.Name = "btn_odalar";
            this.btn_odalar.Size = new System.Drawing.Size(116, 104);
            this.btn_odalar.TabIndex = 3;
            this.btn_odalar.Text = "Odalar";
            this.btn_odalar.UseVisualStyleBackColor = false;
            this.btn_odalar.Click += new System.EventHandler(this.btn_odalar_Click);
            // 
            // btn_musteri_liste
            // 
            this.btn_musteri_liste.BackColor = System.Drawing.Color.White;
            this.btn_musteri_liste.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_musteri_liste.Location = new System.Drawing.Point(803, 530);
            this.btn_musteri_liste.Name = "btn_musteri_liste";
            this.btn_musteri_liste.Size = new System.Drawing.Size(116, 104);
            this.btn_musteri_liste.TabIndex = 4;
            this.btn_musteri_liste.Text = "Müşteriler";
            this.btn_musteri_liste.UseVisualStyleBackColor = false;
            this.btn_musteri_liste.Click += new System.EventHandler(this.btn_musteri_liste_Click);
            // 
            // btn_personel
            // 
            this.btn_personel.BackColor = System.Drawing.Color.White;
            this.btn_personel.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_personel.Location = new System.Drawing.Point(681, 643);
            this.btn_personel.Name = "btn_personel";
            this.btn_personel.Size = new System.Drawing.Size(116, 104);
            this.btn_personel.TabIndex = 5;
            this.btn_personel.Text = "Personel İşlemleri";
            this.btn_personel.UseVisualStyleBackColor = false;


            // 
            // btn_stok
            // 
            this.btn_stok.BackColor = System.Drawing.Color.White;
            this.btn_stok.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stok.Location = new System.Drawing.Point(803, 643);
            this.btn_stok.Name = "btn_stok";
            this.btn_stok.Size = new System.Drawing.Size(116, 104);
            this.btn_stok.TabIndex = 6;
            this.btn_stok.Text = "Stok Kontrolü";
            this.btn_stok.UseVisualStyleBackColor = false;
            // 
            // btn_feedback
            // 
            this.btn_feedback.BackColor = System.Drawing.Color.White;
            this.btn_feedback.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_feedback.Location = new System.Drawing.Point(925, 643);
            this.btn_feedback.Name = "btn_feedback";
            this.btn_feedback.Size = new System.Drawing.Size(116, 104);
            this.btn_feedback.TabIndex = 7;
            this.btn_feedback.Text = "Geri Bildirimler";
            this.btn_feedback.UseVisualStyleBackColor = false;
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.White;
            this.btn_info.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_info.Location = new System.Drawing.Point(1047, 643);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(116, 104);
            this.btn_info.TabIndex = 8;
            this.btn_info.Text = "İnfomation";
            this.btn_info.UseVisualStyleBackColor = false;
            this.btn_info.Click += new System.EventHandler(this.btn_info_Click);
            // 
            // BellWood_AnaMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1175, 759);
            this.Controls.Add(this.btn_info);
            this.Controls.Add(this.btn_feedback);
            this.Controls.Add(this.btn_stok);
            this.Controls.Add(this.btn_personel);
            this.Controls.Add(this.btn_musteri_liste);
            this.Controls.Add(this.btn_odalar);
            this.Controls.Add(this.btn_yeni_musteri_ekle);
            this.Controls.Add(this.btn_admin_giris);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BellWood_AnaMenu";
            this.Text = "BellWood Ana Menü";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_admin_giris;
        private System.Windows.Forms.Button btn_yeni_musteri_ekle;
        private System.Windows.Forms.Button btn_odalar;
        private System.Windows.Forms.Button btn_musteri_liste;
        private System.Windows.Forms.Button btn_personel;
        private System.Windows.Forms.Button btn_stok;
        private System.Windows.Forms.Button btn_feedback;
        private System.Windows.Forms.Button btn_info;
    }
}