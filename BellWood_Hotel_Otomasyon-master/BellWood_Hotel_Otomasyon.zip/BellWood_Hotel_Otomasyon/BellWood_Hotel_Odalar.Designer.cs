﻿namespace BellWood_Hotel_Otomasyon
{
    partial class BellWood_Hotel_Odalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.btn_1008 = new System.Windows.Forms.Button();
            this.btn_1007 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.btn_1006 = new System.Windows.Forms.Button();
            this.btn_1005 = new System.Windows.Forms.Button();
            this.btn_1004 = new System.Windows.Forms.Button();
            this.btn_1003 = new System.Windows.Forms.Button();
            this.btn_1002 = new System.Windows.Forms.Button();
            this.btn_1001 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(1468, 284);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(202, 130);
            this.button1.TabIndex = 19;
            this.button1.Text = "3008";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Location = new System.Drawing.Point(1260, 284);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(202, 130);
            this.button2.TabIndex = 18;
            this.button2.Text = "3007";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(1052, 284);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(202, 130);
            this.button3.TabIndex = 17;
            this.button3.Text = "3006";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Lime;
            this.button4.Location = new System.Drawing.Point(844, 284);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(202, 130);
            this.button4.TabIndex = 16;
            this.button4.Text = "3005";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Lime;
            this.button5.Location = new System.Drawing.Point(636, 284);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(202, 130);
            this.button5.TabIndex = 15;
            this.button5.Text = "3004";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Lime;
            this.button6.Location = new System.Drawing.Point(220, 287);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(202, 130);
            this.button6.TabIndex = 14;
            this.button6.Text = "3002";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Lime;
            this.button7.Location = new System.Drawing.Point(428, 284);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(202, 130);
            this.button7.TabIndex = 14;
            this.button7.Text = "3003";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Lime;
            this.button8.Location = new System.Drawing.Point(12, 284);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(202, 130);
            this.button8.TabIndex = 13;
            this.button8.Text = "3001";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Lime;
            this.button9.Location = new System.Drawing.Point(1260, 148);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(202, 130);
            this.button9.TabIndex = 12;
            this.button9.Text = "2007";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Lime;
            this.button10.Location = new System.Drawing.Point(1468, 148);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(202, 130);
            this.button10.TabIndex = 12;
            this.button10.Text = "2008";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Lime;
            this.button11.Location = new System.Drawing.Point(844, 148);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(202, 130);
            this.button11.TabIndex = 11;
            this.button11.Text = "2005";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Lime;
            this.button12.Location = new System.Drawing.Point(636, 148);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(202, 130);
            this.button12.TabIndex = 10;
            this.button12.Text = "2004";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Lime;
            this.button13.Location = new System.Drawing.Point(1052, 148);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(202, 130);
            this.button13.TabIndex = 10;
            this.button13.Text = "2006";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Lime;
            this.button14.Location = new System.Drawing.Point(428, 148);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(202, 130);
            this.button14.TabIndex = 9;
            this.button14.Text = "2003";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Lime;
            this.button15.Location = new System.Drawing.Point(220, 148);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(202, 130);
            this.button15.TabIndex = 8;
            this.button15.Text = "2002";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // btn_1008
            // 
            this.btn_1008.BackColor = System.Drawing.Color.Lime;
            this.btn_1008.Location = new System.Drawing.Point(1468, 12);
            this.btn_1008.Name = "btn_1008";
            this.btn_1008.Size = new System.Drawing.Size(202, 130);
            this.btn_1008.TabIndex = 7;
            this.btn_1008.Text = "1008";
            this.btn_1008.UseVisualStyleBackColor = false;
            // 
            // btn_1007
            // 
            this.btn_1007.BackColor = System.Drawing.Color.Lime;
            this.btn_1007.Location = new System.Drawing.Point(1260, 12);
            this.btn_1007.Name = "btn_1007";
            this.btn_1007.Size = new System.Drawing.Size(202, 130);
            this.btn_1007.TabIndex = 6;
            this.btn_1007.Text = "1007";
            this.btn_1007.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Lime;
            this.button18.Location = new System.Drawing.Point(12, 148);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(202, 130);
            this.button18.TabIndex = 6;
            this.button18.Text = "2001";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // btn_1006
            // 
            this.btn_1006.BackColor = System.Drawing.Color.Lime;
            this.btn_1006.Location = new System.Drawing.Point(1052, 12);
            this.btn_1006.Name = "btn_1006";
            this.btn_1006.Size = new System.Drawing.Size(202, 130);
            this.btn_1006.TabIndex = 5;
            this.btn_1006.Text = "1006";
            this.btn_1006.UseVisualStyleBackColor = false;
            // 
            // btn_1005
            // 
            this.btn_1005.BackColor = System.Drawing.Color.Lime;
            this.btn_1005.Location = new System.Drawing.Point(844, 12);
            this.btn_1005.Name = "btn_1005";
            this.btn_1005.Size = new System.Drawing.Size(202, 130);
            this.btn_1005.TabIndex = 4;
            this.btn_1005.Text = "1005";
            this.btn_1005.UseVisualStyleBackColor = false;
            // 
            // btn_1004
            // 
            this.btn_1004.BackColor = System.Drawing.Color.Lime;
            this.btn_1004.Location = new System.Drawing.Point(636, 12);
            this.btn_1004.Name = "btn_1004";
            this.btn_1004.Size = new System.Drawing.Size(202, 130);
            this.btn_1004.TabIndex = 3;
            this.btn_1004.Text = "1004";
            this.btn_1004.UseVisualStyleBackColor = false;
            // 
            // btn_1003
            // 
            this.btn_1003.BackColor = System.Drawing.Color.Lime;
            this.btn_1003.Location = new System.Drawing.Point(428, 12);
            this.btn_1003.Name = "btn_1003";
            this.btn_1003.Size = new System.Drawing.Size(202, 130);
            this.btn_1003.TabIndex = 2;
            this.btn_1003.Text = "1003";
            this.btn_1003.UseVisualStyleBackColor = false;
            // 
            // btn_1002
            // 
            this.btn_1002.BackColor = System.Drawing.Color.Lime;
            this.btn_1002.Location = new System.Drawing.Point(220, 12);
            this.btn_1002.Name = "btn_1002";
            this.btn_1002.Size = new System.Drawing.Size(202, 130);
            this.btn_1002.TabIndex = 1;
            this.btn_1002.Text = "1002";
            this.btn_1002.UseVisualStyleBackColor = false;
            // 
            // btn_1001
            // 
            this.btn_1001.BackColor = System.Drawing.Color.Lime;
            this.btn_1001.Location = new System.Drawing.Point(12, 12);
            this.btn_1001.Name = "btn_1001";
            this.btn_1001.Size = new System.Drawing.Size(202, 130);
            this.btn_1001.TabIndex = 0;
            this.btn_1001.Text = "1001";
            this.btn_1001.UseVisualStyleBackColor = false;
            this.btn_1001.Click += new System.EventHandler(this.button24_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::BellWood_Hotel_Otomasyon.Properties.Resources.simple_blue_background_abstract_photo_blue_background;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1681, 430);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // BellWood_Hotel_Odalar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1681, 430);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btn_1001);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btn_1002);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btn_1003);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btn_1004);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btn_1005);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.btn_1006);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.btn_1007);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.btn_1008);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.pictureBox1);
            this.Name = "BellWood_Hotel_Odalar";
            this.Text = "BellWood_Hotel_Odalar";
            this.Load += new System.EventHandler(this.BellWood_Hotel_Odalar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button btn_1008;
        private System.Windows.Forms.Button btn_1007;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button btn_1006;
        private System.Windows.Forms.Button btn_1005;
        private System.Windows.Forms.Button btn_1004;
        private System.Windows.Forms.Button btn_1003;
        private System.Windows.Forms.Button btn_1002;
        private System.Windows.Forms.Button btn_1001;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}